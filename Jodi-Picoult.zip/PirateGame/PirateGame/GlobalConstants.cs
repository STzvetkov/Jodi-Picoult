﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PirateGame
{
    class GlobalConstants
    {
        public static readonly int WINDOW_WIDTH = 800;
        public static readonly int WINDOW_HEIGHT = 600;
    }
}
