﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PirateGame.Ships;

namespace PirateGame.Interfaces
{
    interface IUpgrade
    {
        void UpgradeShip();

    }
}
